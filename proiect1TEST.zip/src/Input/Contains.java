package Input;

import java.util.ArrayList;

public class Contains {
    ArrayList<String> actors = new ArrayList<>();
    ArrayList<String> genre = new ArrayList<>();

    public Contains() {
    }

    public ArrayList<String> getActors() {
        return actors;
    }

    public void setActors(ArrayList<String> actors) {
        this.actors = actors;
    }

    public ArrayList<String> getGenre() {
        return genre;
    }

    public void setGenre(ArrayList<String> genre) {
        this.genre = genre;
    }
}
