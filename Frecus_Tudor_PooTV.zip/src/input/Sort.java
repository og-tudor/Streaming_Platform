package input;

public class Sort {
    private String rating;
    private String duration;

    public Sort() {
    }
    /** Getter */
    public String getRating() {
        return rating;
    }
    /** Setter */
    public void setRating(final String rating) {
        this.rating = rating;
    }
    /** Getter */
    public String getDuration() {
        return duration;
    }
    /** Setter */
    public void setDuration(final String duration) {
        this.duration = duration;
    }
}
