package input;

public class CustomRating {
    private final Double rating;

    public CustomRating(Double rating) {
        this.rating = rating;
    }

    public Double getRating() {
        return rating;
    }
}
